# Contributors to OpenFOAM

The following is a list of known contributors to OpenFOAM.
It is likely incomplete...

## Contributors (alphabetical by surname)

- Tetsuo Aoyagi
- Akira Azami
- William Bainbridge
- Gabriel Barajas
- Kutalmis Bercin
- Ivor Clifford
- Greg Collecutt
- Jonathan Cranford
- Sergio Ferraris
- Matej Forman
- Marian Fuchs
- Pawan Ghildiyal
- Chris Greenshields
- Bernhard Gschaider
- Andrew Heather
- David Hill
- Yoshiaki Inoue
- Mattijs Janssens
- Andrew Jackson
- Hrvoje Jasak
- Alexander Kabat vel Job
- Thilo Knacke
- Shannon Leakey
- Tommaso Lucchini
- Graham Macpherson
- Alexey Matveichev
- Karl Meredith
- Laurence McGlashan
- Timo Niemi
- Haakan Nilsson
- Niklas Nordin
- Mark Olesen
- Victor Olesen
- Evangelos Papoutsis-Kiachagias
- Juho Peltola
- Johan Roenby
- Henrik Rusche
- Bruno Santos
- Henning Scheufler
- Richard Smith
- Prashant Sonakar
- Hilary Spencer
- Gavin Tabor
- Zeljko Tukovic
- Eugene De Villiers
- Yi Wang
- Norbert Weber
- Henry Weller
- Niklas Wikstrom
- Guanyang Xue
- Thorsten Zirwes

<!----------------------------------------------------------------------------->
