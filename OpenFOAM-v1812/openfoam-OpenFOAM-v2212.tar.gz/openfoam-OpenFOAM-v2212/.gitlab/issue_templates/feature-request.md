### Functionality to add/problem to solve

(Brief scope)


### Target audience

(Who will benefit from the changes?)
(What type of cases?)


### Proposal

(How are we going to solve the problem?)


### What does success look like, and how can we measure that?

(What are the success factors and acceptance criteria? e.g. test cases, error margins)


### Links / references

(Links to literature, supporting information)


### Funding

(Does the functionality already exist/is sponsorship available?)

/label ~feature
